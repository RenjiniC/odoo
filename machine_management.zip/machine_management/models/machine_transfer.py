# -*- coding: utf-8 -*-
from odoo import fields, models


class MachineTransfer(models.Model):
    _name = "machine.transfer"

    machine_name = fields.Many2one('machine.management',
                                   change_default=True)
    machine_serial_no = fields.Char(related='machine_name.machine_serial_no')
    transfer_date = fields.Date(string='Date')
    transfer_type = fields.Selection([('install', 'Install'),
                                      ('remove', 'Remove')])
    customer_id = fields.Many2one(comodel_name='res.partner',
                                  string='Customer',
                                  required=True,
                                  tracking=True,)
    internal_notes = fields.Char(string='Internal Notes')

    def transfer_action(self):
        obj1 = self.machine_name.write({'customer_id': self.customer_id.id,
                                        'state': 'in_service',
                                        })







