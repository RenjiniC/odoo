# -*- coding: utf-8 -*-
from odoo import fields, models, api, _
from odoo.exceptions import ValidationError

MACHINE_STATE = [
    ('active', "Active"),
    ('in_service', "In Service"),
]


class MachineManagement(models.Model):
    _name = "machine.management"
    _inherit = "mail.thread"
    _rec_name = "machine_name"

    reference_no = fields.Char(string='New', readonly=True,
                               default=lambda self: _('New'))
    machine_name = fields.Char(string='MachineName', help="Machine Name")
    machine_serial_no = fields.Char(string='Serial No')
    date_of_purchase = fields.Date(string='Date',
                                   help="Purchase Date of machine")
    currency_id = fields.Many2one(comodel_name='res.currency',
                                  compute='_compute_currency_id')
    purchase_value = fields.Monetary(string='Purchase Value',
                                     currency_field='currency_id',
                                     tracking=True, widget='monetary',
                                     help="Purchase Amount of machine")
    image = fields.Binary(widget="image", help="Image of the Machine")
    instruction = fields.Html(string='Instructions',
                              help="Instructions regarding the machine")
    customer_id = fields.Many2one(comodel_name='res.partner', string='Customer',
                                  required=True,
                                  tracking=True,
                                  help="Name of the customer of the machine")
    company_id = fields.Many2one(comodel_name='res.company', string='Company',
                                 help="Name of the company")
    machine_type = fields.Many2one('machine.type',
                                   change_default=True)
    state = fields.Selection(selection=MACHINE_STATE, string="Status",
                             required=True,
                             copy=False,
                             index=True,
                             default='active',
                             tracking=True)
    description = fields.Char(string='Description',
                              help="Description of the Machine")
    warranty = fields.Selection([('yes', 'YES'), ('no', 'No')],
                                tracking=True, help="Warranty of the machine")
    machine_transfer_count = fields.Integer(string="Machine Transfer",
                                            compute='_machine_transfer_count',
                                            default=0)

    @api.model
    def create(self, vals):
        if vals.get('reference_no', _('New')) == _('New'):
            vals['reference_no'] = self.env['ir.sequence'].next_by_code(
                'machine') or _('New')
        return super(MachineManagement, self).create(vals)

    @api.model
    @api.constrains('purchase_value')
    def _check_values(self):
        if self.purchase_value <= 0.0:
            raise ValidationError(_('Purchase Values should greater than 0.'))

    @api.constrains('machine_serial_no')
    def _check_serial_no(self):
        for rec in self:
            domain = [('machine_serial_no', '=', rec.machine_serial_no)]

            count = self.sudo().search_count(domain)
            if count > 1:
                raise ValidationError(_("The Serial No should be unique"))

    @api.depends('company_id')
    def _compute_currency_id(self):
        main_company = self.env['res.company']._get_main_company()
        for template in self:
            template.currency_id = (template.company_id.sudo().currency_id.id or
                                    main_company.currency_id.id)

    @staticmethod
    def redirect_new(self):
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'machine.transfer',
            'view_mode': 'tree',
            'view_type': 'form',
        }

    def _machine_transfer_count(self):
        for new in self:
            new.machine_transfer_count = (self.env['machine.transfer'].
                                          search_count(
                [('machine_name', '=', self.machine_name)]))

    def transfer_history(self):
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'machine.transfer',
            'view_mode': 'tree,form',
            'view_type': 'tree',
            'domain': [('machine_name', '=', self.machine_name)],
        }
