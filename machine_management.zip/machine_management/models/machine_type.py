# -*- coding: utf-8 -*-
from odoo import fields, models


class MachineType(models.Model):
    _name = 'machine.type'

    name = fields.Char('Name')