{
    'name': 'MACHINE MANAGEMENT',
    'depends': ['base','mail'],
    'version': '17.0.1.0',
    'application': True,
    'license': 'LGPL-3',
    'summery': 'Machine Management',
    'category': '',
    'author': 'Renjini',
    'sequence': 11,

    'data': [

             'view/machine_view.xml',
             'view/machine_menu.xml',
             'view/machine_reference.xml',
             'view/machine_type_menu.xml',
             'security/ir.model.access.csv',
             'data/machine_type_data.xml',
             'view/machine_transfer_view.xml',


    ],
}
