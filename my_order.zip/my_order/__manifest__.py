{
    'name': 'My Order',
    'depends': ['base','sale','stock'],
    'version': '17.0.1.0.0',
    'application': True,
    'license': 'LGPL-3',
    'summery': 'My Order',
    'category': '',
    'author': 'Renjini',
    'sequence': 10,

    'data': [


                 'views/my_delivery_view.xml',
                 'views/my_contact.xml',


        ],
}