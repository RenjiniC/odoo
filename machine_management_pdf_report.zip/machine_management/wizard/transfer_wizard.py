# -*- coding: utf-8 -*-
from odoo import models, fields


class TransferWizard(models.TransientModel):
    _name = 'transfer.wizard'

    from_date = fields.Date(string='From Date', required=True)
    to_date = fields.Date(string='To Date', required=True)
    customer_id = fields.Many2one('res.partner', 'Customer',
                                  required=True)

    transfer_type = fields.Selection([('install', 'Install'),
                                      ('remove', 'Remove')],
                                     'Transfer Type',
                                     required=True)

    machine_name_id = fields.Many2one('machine.management',
                                      'Machine',
                                      required=True)

    def action_done(self):
        query = """select * from machine_transfer where transfer_date between %s and %s
                AND transfer_type = %s
                AND customer_id = %s
                AND machine_name_id = %s
                """
        record = [self.from_date,
                  self.to_date,
                  self.transfer_type,
                  self.customer_id.id,
                  self.machine_name_id.id]
        self.env.cr.execute(query, tuple(record))
        report = self.env.cr.dictfetchall()
        data = {'date': self.read()[0], 'report': report}
        return self.env.ref(
            'machine_management.action_report_machine_transfer').report_action(
                                                            None, data=data)
