# -*- coding: utf-8 -*-
from odoo import fields, models, api, _, Command

SERVICE_STATE = [
    ('open', "Open"),
    ('started', "Started"),
    ('done', "Done"),
    ('cancel', "Cancel")
    ]


class MachineService(models.Model):
    _name = "machine.service"
    _description = "Machine Services"
    _inherit = ['mail.thread']
    _rec_name = "reference_no"

    reference_no = fields.Char(string='Reference', readonly=True,
                               default=lambda self: _('New'))
    machine_name_id = fields.Many2one('machine.management',
                                      tracking=True,
                                      required=True)
    customer_id = fields.Many2one(related='machine_name_id.customer_id')
    company_id = fields.Many2one(related='machine_name_id.company_id')
    date = fields.Date(string='Date',
                       help="Service Date of machine",
                       required=True)
    description = fields.Char('Description')
    internal_notes = fields.Char('Internal Notes')
    tech_person = fields.Many2many(comodel_name='res.users',
                                   string="Tech Person")
    parts_consumed = fields.One2many(
                            related='machine_name_id.product_order_line_ids',
                            string='Parts Consumed')
    state = fields.Selection(selection=SERVICE_STATE, string="Status",
                             required=True,
                             copy=False,
                             index=True,
                             default='open',
                             tracking=True)

    @api.model
    def create(self, vals):
        """To create Sequence number"""
        if vals.get('reference_no', _('New')) == _('New'):
            vals['reference_no'] = self.env['ir.sequence'].next_by_code(
                'service') or _('New')
        return super(MachineService, self).create(vals)

    def start_case_action(self):
        self.write({'state': 'started'})

    def close_case_action(self):
        self.write({'state': 'done'})

    def create_invoice_action(self):
        """Create invoice for the machine service, add a small amount as a
        service charge by default and add the consumed parts and their price
        in the invoice"""
        for record in self:
            if record.env['account.move'].search([('state', '=', 'draft'),
                                                     ('partner_id', '=',
                                                      record.customer_id.id)]):
                val = record.env['account.move'].search([('state', '=', 'draft'),
                                                      ('partner_id', '=',
                                                       record.customer_id.id)],
                                                        limit=1)
                print(val.invoice_line_ids)
                val.write({
                    'invoice_line_ids': [Command.create({
                                        'name': 'Service Charge',
                                        'price_unit': 100.0})] + [Command.create
                                         ({'product_id': rec.product_id.id,
                                         'price_unit': rec.product_id.lst_price
                                         }) for rec in record.parts_consumed
                                        ]})
            else:
                service_invoice = record.env['account.move'].create([
                    {
                        'move_type': 'out_invoice',
                        'invoice_date': fields.Date.today(),
                        'partner_id': record.customer_id.id,
                        'currency_id': record.machine_name_id.currency_id.id,
                        'amount_total': record.machine_name_id.parts_ids.product_id.
                        lst_price,
                        'invoice_line_ids': [Command.create({
                                            'name': 'Service Charge',
                                            'price_unit': 100.0})]+[Command.create(
                                             {'product_id': rec.product_id.id,
                                             'price_unit': rec.product_id.lst_price
                                             })for rec in record.parts_consumed
                        ]},
                ])
                print(service_invoice)
                service_invoice.action_post()
