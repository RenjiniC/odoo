{
    'name': 'Sale Discount Limit',
    'depends': ['base', 'sale'],
    'version': '17.0.1.0',
    'license': 'LGPL-3',
    'summery': 'Sale Discount Limit',
    'category': '',
    'author': 'Renjini',
    'sequence': 12,

    'data': [
             'views/res_config_settings_views.xml',

    ],
}
