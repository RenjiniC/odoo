{
    'name': 'MACHINE MANAGEMENT',
    'depends': ['base','mail','product'],
    'version': '17.0.1.0',
    'application': True,
    'license': 'LGPL-3',
    'summery': 'Machine Management',
    'category': '',
    'author': 'Renjini',
    'sequence': 11,

    'data': [
             'security/ir.model.access.csv',
             'data/machine_type_data.xml',
             'data/machine_tag_data.xml',
             'view/machine_views.xml',
             'view/machine_menu.xml',
             'view/machine_reference_sequence.xml',
             'view/machine_type_menu.xml',
             'view/machine_transfer_views.xml',
             'view/machine_tag_menu.xml',

    ],
}
